<?php

repair_el_type_collate();
